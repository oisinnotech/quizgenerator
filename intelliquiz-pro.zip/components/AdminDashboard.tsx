
import React, { useState, useEffect } from 'react';
import { QuizItem, SubQuestion, QuizReport } from '../types';
import { Button } from './Button';
import { analyzeQuizContext } from '../services/gemini';

interface AdminDashboardProps {
  onBack: () => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onBack }) => {
  const [quizzes, setQuizzes] = useState<QuizItem[]>([]);
  const [reports, setReports] = useState<QuizReport[]>([]);
  const [isAdding, setIsAdding] = useState(false);
  const [view, setView] = useState<'QUIZZES' | 'REPORTS'>('QUIZZES');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [mediaType, setMediaType] = useState<'image' | 'pdf'>('image');
  const [mediaData, setMediaData] = useState<string>('');
  const [mainQuestionMediaType, setMainQuestionMediaType] = useState<'image' | 'pdf'>('image');
  const [mainQuestionMediaData, setMainQuestionMediaData] = useState<string>('');
  const [subQuestions, setSubQuestions] = useState<SubQuestion[]>([]);
  const [displayContextAlways, setDisplayContextAlways] = useState(true);

  useEffect(() => {
    const savedQuizzes = localStorage.getItem('intelli_quizzes');
    if (savedQuizzes) setQuizzes(JSON.parse(savedQuizzes));

    const savedReports = localStorage.getItem('intelli_reports');
    if (savedReports) setReports(JSON.parse(savedReports));
  }, []);

  const saveToLocal = (updated: QuizItem[]) => {
    setQuizzes(updated);
    localStorage.setItem('intelli_quizzes', JSON.stringify(updated));
  };

  const clearReports = () => {
    if (confirm('Are you sure you want to clear all student reports?')) {
      setReports([]);
      localStorage.setItem('intelli_reports', JSON.stringify([]));
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, target: 'source' | 'main') => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const data = reader.result as string;
      const type = file.type.includes('pdf') ? 'pdf' : 'image';
      if (target === 'source') {
        setMediaData(data);
        setMediaType(type);
      } else {
        setMainQuestionMediaData(data);
        setMainQuestionMediaType(type);
      }
    };
    reader.readAsDataURL(file);
  };

  const generateAIAssistance = async () => {
    if (!mediaData) return;
    setIsAnalyzing(true);
    const suggested = await analyzeQuizContext(mediaData, mediaType);
    const formatted = suggested.map((q: any, idx: number) => ({
      ...q,
      id: `sq-${Date.now()}-${idx}`
    }));
    setSubQuestions([...subQuestions, ...formatted]);
    setIsAnalyzing(false);
  };

  const addSubQuestion = () => {
    const newSq: SubQuestion = {
      id: `sq-${Date.now()}`,
      questionText: '',
      options: ['', '', '', ''],
      correctAnswerIndex: 0
    };
    setSubQuestions([...subQuestions, newSq]);
  };

  const removeQuiz = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (confirm('Are you sure you want to delete this quiz?')) {
      saveToLocal(quizzes.filter(q => q.id !== id));
    }
  };

  const startEdit = (quiz: QuizItem) => {
    setEditingId(quiz.id);
    setTitle(quiz.title);
    setDescription(quiz.description);
    setMediaType(quiz.mediaType);
    setMediaData(quiz.mediaData);
    setSubQuestions(quiz.subQuestions);
    setDisplayContextAlways(quiz.displayContextAlways);
    setMainQuestionMediaData(quiz.mainQuestionMediaData || '');
    setMainQuestionMediaType(quiz.mainQuestionMediaType || 'image');
    setIsAdding(true);
  };

  const saveQuiz = () => {
    if (!title || !mediaData) return alert('Title and AI Source Material are required!');
    
    const quizData: QuizItem = {
      id: editingId || `quiz-${Date.now()}`,
      title,
      description,
      mediaType,
      mediaData,
      subQuestions,
      createdAt: editingId ? (quizzes.find(q => q.id === editingId)?.createdAt || Date.now()) : Date.now(),
      displayContextAlways,
      mainQuestionMediaData: displayContextAlways ? mainQuestionMediaData : undefined,
      mainQuestionMediaType: displayContextAlways ? mainQuestionMediaType : undefined,
    };

    let updatedQuizzes;
    if (editingId) {
      updatedQuizzes = quizzes.map(q => q.id === editingId ? quizData : q);
    } else {
      updatedQuizzes = [...quizzes, quizData];
    }

    saveToLocal(updatedQuizzes);
    resetForm();
    setIsAdding(false);
  };

  const resetForm = () => {
    setTitle('');
    setDescription('');
    setMediaData('');
    setMainQuestionMediaData('');
    setSubQuestions([]);
    setDisplayContextAlways(true);
    setEditingId(null);
  };

  return (
    <div className="max-w-6xl mx-auto p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-4">
        <div>
          <h1 className="text-4xl font-black text-slate-900 tracking-tight">Admin Control</h1>
          <div className="flex gap-4 mt-2">
            <button 
              onClick={() => setView('QUIZZES')}
              className={`text-sm font-bold uppercase tracking-widest pb-1 border-b-2 transition-all ${view === 'QUIZZES' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
            >
              Assessments
            </button>
            <button 
              onClick={() => setView('REPORTS')}
              className={`text-sm font-bold uppercase tracking-widest pb-1 border-b-2 transition-all ${view === 'REPORTS' ? 'border-indigo-600 text-indigo-600' : 'border-transparent text-slate-400 hover:text-slate-600'}`}
            >
              Student Reports
            </button>
          </div>
        </div>
        <div className="space-x-4">
          <Button variant="secondary" className="font-bold" onClick={onBack}>Exit Admin</Button>
          {view === 'QUIZZES' && !isAdding && (
            <Button onClick={() => setIsAdding(true)} className="font-black shadow-lg shadow-indigo-100">Create New Quiz</Button>
          )}
        </div>
      </div>

      {view === 'REPORTS' ? (
        <div className="bg-white rounded-[2rem] shadow-xl border border-slate-100 overflow-hidden">
          <div className="p-8 border-b border-slate-50 flex justify-between items-center">
            <h2 className="text-2xl font-black text-slate-900">Performance Dashboard</h2>
            {reports.length > 0 && (
              <Button variant="ghost" size="sm" className="text-red-500 font-bold" onClick={clearReports}>Clear All Reports</Button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50">
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Student Name</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Quiz Title</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Result</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Date & Time</th>
                  <th className="p-6 text-[10px] font-black uppercase tracking-widest text-slate-400 text-right">Score %</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50">
                {reports.map((report) => (
                  <tr key={report.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="p-6 font-bold text-slate-900">{report.userName}</td>
                    <td className="p-6 text-slate-600 font-medium">{report.quizTitle}</td>
                    <td className="p-6">
                      <span className={`px-3 py-1 rounded-full text-[10px] font-black ${
                        (report.score / report.total) >= 0.8 ? 'bg-emerald-100 text-emerald-700' :
                        (report.score / report.total) >= 0.5 ? 'bg-indigo-100 text-indigo-700' : 'bg-red-100 text-red-700'
                      }`}>
                        {report.score} / {report.total}
                      </span>
                    </td>
                    <td className="p-6 text-slate-400 text-xs font-medium">
                      {new Date(report.timestamp).toLocaleString()}
                    </td>
                    <td className="p-6 text-right">
                      <span className="font-black text-slate-900">
                        {Math.round((report.score / report.total) * 100)}%
                      </span>
                    </td>
                  </tr>
                ))}
                {reports.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-20 text-center text-slate-300 font-medium italic">
                      No reports generated yet.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      ) : isAdding ? (
        <div className="bg-white rounded-[2.5rem] shadow-2xl border border-gray-100 p-10 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <h2 className="text-3xl font-black mb-8 text-indigo-900">{editingId ? 'Modify Assessment' : 'New Comprehensive Assessment'}</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-10">
            <div className="space-y-8">
              <section className="p-6 bg-indigo-50/50 rounded-3xl border border-indigo-100 shadow-sm">
                <h3 className="text-xs font-black text-indigo-400 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full"></span>
                  AI Content Analysis
                </h3>
                <div className="space-y-4">
                  <label className="block text-sm font-black text-slate-700">Internal Source Material (Hidden)</label>
                  <p className="text-xs text-slate-500 leading-relaxed">Upload reference material. AI will use this to set the right answers.</p>
                  <div className="relative group">
                    <input 
                      type="file" 
                      accept="image/*,application/pdf"
                      onChange={(e) => handleFileUpload(e, 'source')}
                      className="w-full text-sm text-slate-500 file:mr-4 file:py-2.5 file:px-6 file:rounded-xl file:border-0 file:text-xs file:font-black file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 file:transition-all cursor-pointer"
                    />
                  </div>
                  {mediaData && (
                    <div className="mt-6 flex items-center justify-between bg-white p-3 rounded-2xl border border-indigo-100 shadow-sm">
                      <span className="text-xs font-black text-emerald-600 uppercase tracking-widest flex items-center gap-1">
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"></path></svg>
                        Source Ready
                      </span>
                      <Button 
                        size="sm" 
                        variant="secondary" 
                        isLoading={isAnalyzing}
                        onClick={generateAIAssistance}
                        className="text-[10px] font-black py-2"
                      >
                        ✨ GENERATE ITEMS
                      </Button>
                    </div>
                  )}
                </div>
              </section>

              <section className="p-6 bg-slate-50 rounded-3xl border border-slate-200">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-[0.2em] mb-6 flex items-center gap-2">
                   <span className="w-1.5 h-1.5 bg-slate-400 rounded-full"></span>
                   Student Interface Config
                </h3>
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-black text-slate-700 mb-2">Quiz Title</label>
                    <input 
                      type="text" 
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full border-2 border-slate-200 rounded-2xl p-4 text-base font-bold focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 outline-none transition-all"
                      placeholder="e.g. History & Politics Mastery"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-black text-slate-700 mb-2">Main Display Text / Question</label>
                    <textarea 
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="w-full border-2 border-slate-200 rounded-2xl p-4 text-sm font-medium focus:ring-4 focus:ring-indigo-100 focus:border-indigo-600 outline-none h-40 resize-none transition-all"
                      placeholder="The contextual text students will study while answering..."
                    />
                  </div>
                  <div className="p-6 bg-white rounded-2xl border-2 border-slate-100 shadow-sm">
                    <div className="flex items-center space-x-3 mb-4">
                      <input 
                        type="checkbox" 
                        id="displayContextAlways"
                        checked={displayContextAlways}
                        onChange={(e) => setDisplayContextAlways(e.target.checked)}
                        className="w-5 h-5 text-indigo-600 rounded-lg cursor-pointer"
                      />
                      <label htmlFor="displayContextAlways" className="text-sm font-bold text-slate-700 cursor-pointer">
                        Sync Main Media to all pages
                      </label>
                    </div>
                    {displayContextAlways && (
                      <div className="animate-in slide-in-from-top-2 duration-300 pt-4 border-t border-slate-50">
                        <label className="block text-[10px] font-black text-indigo-600 uppercase tracking-[0.2em] mb-3">Main Student Visual (Optional)</label>
                        <input 
                          type="file" 
                          accept="image/*,application/pdf"
                          onChange={(e) => handleFileUpload(e, 'main')}
                          className="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:bg-indigo-50 file:text-indigo-700 font-bold"
                        />
                      </div>
                    )}
                  </div>
                </div>
              </section>
            </div>

            <div className="space-y-6 flex flex-col">
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-black text-slate-900 tracking-tight">Question Set ({subQuestions.length})</h3>
                <Button variant="ghost" size="sm" onClick={addSubQuestion} className="font-black text-indigo-600 hover:bg-indigo-50">+ Add Item Manually</Button>
              </div>

              <div className="flex-1 max-h-[700px] overflow-y-auto space-y-6 pr-4 scrollbar-hide">
                {subQuestions.map((sq, idx) => (
                  <div key={sq.id} className="p-8 bg-white rounded-[2rem] border-2 border-slate-100 group hover:border-indigo-200 hover:shadow-xl hover:shadow-indigo-50/50 transition-all duration-300">
                    <div className="flex justify-between items-center mb-6">
                      <span className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center text-xs font-black text-white shadow-lg">#{idx + 1}</span>
                      <button 
                        onClick={() => setSubQuestions(subQuestions.filter(s => s.id !== sq.id))}
                        className="p-2 text-slate-300 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                      </button>
                    </div>
                    <div className="space-y-6">
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Question Text</label>
                        <input 
                          className="w-full bg-slate-50 border-2 border-transparent rounded-2xl p-4 text-base font-bold focus:bg-white focus:border-indigo-500 outline-none transition-all"
                          placeholder="Define the question here..."
                          value={sq.questionText}
                          onChange={(e) => {
                            const newSqs = [...subQuestions];
                            newSqs[idx].questionText = e.target.value;
                            setSubQuestions(newSqs);
                          }}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-indigo-500 tracking-widest">Mark Right Answer (Radio Button)</label>
                        <div className="grid grid-cols-1 gap-3">
                          {sq.options.map((opt, optIdx) => (
                            <div key={optIdx} className={`flex items-center space-x-4 p-3 rounded-2xl group/opt border-2 transition-all ${sq.correctAnswerIndex === optIdx ? 'bg-emerald-50 border-emerald-200' : 'bg-slate-50 border-transparent hover:bg-white hover:border-slate-100'}`}>
                              <input 
                                type="radio" 
                                name={`correct-${sq.id}`} 
                                checked={sq.correctAnswerIndex === optIdx}
                                onChange={() => {
                                  const newSqs = [...subQuestions];
                                  newSqs[idx].correctAnswerIndex = optIdx;
                                  setSubQuestions(newSqs);
                                }}
                                className="w-5 h-5 text-emerald-600 cursor-pointer accent-emerald-600"
                              />
                              <input 
                                className="flex-1 bg-transparent border-none p-1 focus:outline-none font-bold text-slate-700 placeholder:text-slate-300"
                                placeholder={`Option ${String.fromCharCode(65 + optIdx)}`}
                                value={opt}
                                onChange={(e) => {
                                  const newSqs = [...subQuestions];
                                  newSqs[idx].options[optIdx] = e.target.value;
                                  setSubQuestions(newSqs);
                                }}
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {subQuestions.length === 0 && (
                  <div className="py-24 text-center text-slate-300 border-4 border-dashed border-slate-50 rounded-[3rem] flex flex-col items-center gap-4">
                     <svg className="w-16 h-16 opacity-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
                     <p className="font-black uppercase tracking-widest text-[10px]">Your question set is empty</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-4 pt-10 border-t border-slate-50">
            <Button variant="ghost" onClick={() => { setIsAdding(false); setEditingId(null); }} className="font-bold">Discard Changes</Button>
            <Button onClick={saveQuiz} className="px-12 py-4 rounded-2xl font-black shadow-2xl shadow-indigo-100 transform active:scale-95 transition-transform">
              {editingId ? 'Save Modifications' : 'Publish Assessment'}
            </Button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {quizzes.map(quiz => (
            <div 
              key={quiz.id} 
              className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden group hover:shadow-3xl hover:-translate-y-2 transition-all duration-500 cursor-pointer flex flex-col h-[420px]"
              onClick={() => startEdit(quiz)}
            >
              <div className="h-44 bg-slate-900 flex items-center justify-center relative overflow-hidden">
                {quiz.mainQuestionMediaData ? (
                   <img src={quiz.mainQuestionMediaData} alt="Cover" className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-700 opacity-80" />
                ) : (
                   <div className="p-8 text-center text-slate-700">
                     <svg className="w-16 h-16 mx-auto mb-2 opacity-10" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd"></path></svg>
                   </div>
                )}
                <div className="absolute top-6 right-6 z-20">
                  <button 
                    onClick={(e) => removeQuiz(quiz.id, e)}
                    className="p-3 bg-white/10 backdrop-blur-md text-white/50 rounded-2xl hover:bg-red-600 hover:text-white transition-all shadow-xl"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                  </button>
                </div>
                <div className="absolute bottom-6 left-6 flex gap-2">
                   <span className="bg-white/10 backdrop-blur-md text-white text-[9px] font-black uppercase tracking-widest px-3 py-1 rounded-full border border-white/20">
                     {quiz.subQuestions.length} Questions
                   </span>
                </div>
              </div>
              <div className="p-8 flex-1 flex flex-col">
                <h3 className="font-black text-2xl text-slate-900 group-hover:text-indigo-600 transition-colors mb-3 line-clamp-1">{quiz.title}</h3>
                <p className="text-sm text-slate-500 mb-8 line-clamp-3 font-medium leading-relaxed">{quiz.description}</p>
                <div className="mt-auto flex justify-between items-center pt-6 border-t border-slate-50">
                  <span className={`text-[10px] font-black uppercase tracking-[0.2em] px-3 py-1 rounded-full ${quiz.displayContextAlways ? 'bg-indigo-50 text-indigo-600' : 'bg-slate-50 text-slate-400'}`}>
                    {quiz.displayContextAlways ? 'Comp-View' : 'Standard'}
                  </span>
                  <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">Modified {new Date(quiz.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
          {quizzes.length === 0 && (
            <div className="col-span-full py-40 text-center text-slate-300 border-4 border-dashed border-slate-50 rounded-[4rem]">
              <div className="w-24 h-24 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-8 shadow-inner">
                <svg className="w-12 h-12 opacity-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"></path></svg>
              </div>
              <h3 className="text-3xl font-black text-slate-400 mb-3 tracking-tight">Your Vault is Empty</h3>
              <p className="font-bold text-slate-400">Click "Create New Quiz" to define your first assessment.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
