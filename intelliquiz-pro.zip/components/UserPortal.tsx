
import React, { useState, useEffect } from 'react';
import { QuizItem, UserState, UserResponse, QuizReport } from '../types';
import { Button } from './Button';

interface UserPortalProps {
  onBack: () => void;
}

interface QuizResults {
  score: number;
  correct: number;
  wrong: number;
  unattempted: number;
  total: number;
}

type PortalView = 'DASHBOARD' | 'QUIZ' | 'RESULTS';

export const UserPortal: React.FC<UserPortalProps> = ({ onBack }) => {
  const [quizzes, setQuizzes] = useState<QuizItem[]>([]);
  const [user, setUser] = useState<UserState | null>(null);
  const [activeQuiz, setActiveQuiz] = useState<QuizItem | null>(null);
  const [userNameInput, setUserNameInput] = useState('');
  const [results, setResults] = useState<QuizResults | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [isZoomed, setIsZoomed] = useState(false);
  const [view, setView] = useState<PortalView>('DASHBOARD');

  useEffect(() => {
    const saved = localStorage.getItem('intelli_quizzes');
    if (saved) {
      try {
        setQuizzes(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse quizzes", e);
      }
    }
  }, []);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userNameInput.trim()) return;
    setUser({ name: userNameInput, responses: [] });
    setView('DASHBOARD');
  };

  const handleSelectQuiz = (quiz: QuizItem) => {
    if (!quiz.subQuestions || quiz.subQuestions.length === 0) {
      alert("This assessment has no questions configured.");
      return;
    }
    setActiveQuiz(quiz);
    setResults(null);
    setCurrentQuestionIndex(0);
    setView('QUIZ');
  };

  const handleAnswer = (quizId: string, sqId: string, optIdx: number) => {
    if (!user || view !== 'QUIZ') return; 
    const newResponses = [...user.responses].filter(r => r.subQuestionId !== sqId);
    newResponses.push({ quizId, subQuestionId: sqId, selectedOptionIndex: optIdx });
    setUser({ ...user, responses: newResponses });
  };

  const getSubQuestionStatus = (sqId: string) => {
    return user?.responses.some(r => r.subQuestionId === sqId) ? 'ATTENDED' : 'UNATTENDED';
  };

  const handleFinishAssessment = () => {
    // 1. Immediate alert to check if function is called
    window.alert("Submit button clicked! Processing your answers now...");
    console.log("[DEBUG] handleFinishAssessment triggered");
    
    try {
      if (!activeQuiz || !user) {
        throw new Error("Active quiz or user data is missing. Please restart the session.");
      }

      // 2. Logic calculation
      let correct = 0;
      let wrong = 0;
      let skipped = 0;

      activeQuiz.subQuestions.forEach((sq) => {
        const resp = user.responses.find(r => r.subQuestionId === sq.id);
        if (!resp) {
          skipped++;
        } else if (resp.selectedOptionIndex === sq.correctAnswerIndex) {
          correct++;
        } else {
          wrong++;
        }
      });

      const finalResults: QuizResults = {
        score: correct,
        correct,
        wrong,
        unattempted: skipped,
        total: activeQuiz.subQuestions.length
      };

      console.log("[DEBUG] Results calculated:", finalResults);

      // 3. Save report (non-blocking)
      try {
        const report: QuizReport = {
          id: `report-${Date.now()}`,
          userName: user.name,
          quizTitle: activeQuiz.title,
          score: finalResults.score,
          total: finalResults.total,
          timestamp: Date.now(),
          quizId: activeQuiz.id
        };

        const rawReports = localStorage.getItem('intelli_reports');
        let existingReports = [];
        if (rawReports) {
          try { existingReports = JSON.parse(rawReports); } catch (e) {}
        }
        localStorage.setItem('intelli_reports', JSON.stringify([...existingReports, report]));
      } catch (saveError) {
        console.error("Report save failed but proceeding to show results", saveError);
      }

      // 4. Update State and View
      setResults(finalResults);
      setView('RESULTS');
      
      // 5. Final success indicator
      window.alert(`Assessment complete! Score: ${finalResults.score}/${finalResults.total}`);
      window.scrollTo(0, 0);

    } catch (error: any) {
      console.error("[CRITICAL ERROR]", error);
      window.alert("Something went wrong during submission: " + error.message);
    }
  };

  // --- RENDERING BRANCHES ---

  // LOGIN SCREEN
  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-slate-50">
        <div className="max-w-md w-full bg-white rounded-[2.5rem] shadow-2xl p-10 border border-slate-200">
          <div className="text-center mb-10">
            <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl">
              <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
            </div>
            <h1 className="text-4xl font-black text-slate-900 mb-2 tracking-tight">Portal Entry</h1>
            <p className="text-slate-500 font-medium">Identify yourself to begin the assessment.</p>
          </div>
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase text-indigo-500 tracking-widest ml-1">Candidate Name</label>
              <input 
                type="text" 
                required
                value={userNameInput}
                onChange={(e) => setUserNameInput(e.target.value)}
                className="w-full px-6 py-5 rounded-2xl border-2 border-slate-100 focus:border-indigo-600 outline-none font-bold text-xl transition-all shadow-sm"
                placeholder="Full Name"
              />
            </div>
            <Button className="w-full py-6 text-xl font-black rounded-2xl shadow-xl shadow-indigo-100" type="submit">Access Quiz</Button>
            <Button variant="ghost" className="w-full font-bold text-slate-400" onClick={onBack}>Cancel</Button>
          </form>
        </div>
      </div>
    );
  }

  // RESULTS VIEW
  if (view === 'RESULTS' && results && activeQuiz) {
    return (
      <div className="min-h-screen bg-slate-50 p-6 md:p-12">
        <div className="max-w-4xl mx-auto bg-white rounded-[3.5rem] shadow-2xl border border-slate-100 overflow-hidden">
          <div className="bg-gradient-to-br from-emerald-600 to-emerald-900 p-16 text-center text-white">
            <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-6 backdrop-blur-md">
               <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
            </div>
            <h2 className="text-5xl font-black mb-2 tracking-tight">Final Performance</h2>
            <p className="opacity-90 text-2xl font-bold">{user.name}, your results are ready.</p>
          </div>

          <div className="p-10 md:p-16">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
              <div className="bg-slate-50 p-8 rounded-[2rem] text-center border border-slate-100">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Total Score</p>
                <p className="text-5xl font-black text-slate-900 leading-none">{results.score}<span className="text-sm opacity-20">/{results.total}</span></p>
              </div>
              <div className="bg-emerald-50 p-8 rounded-[2rem] text-center border border-emerald-100">
                <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-2">Correct</p>
                <p className="text-5xl font-black text-emerald-700 leading-none">{results.correct}</p>
              </div>
              <div className="bg-red-50 p-8 rounded-[2rem] text-center border border-red-100">
                <p className="text-[10px] font-black text-red-600 uppercase tracking-widest mb-2">Wrong</p>
                <p className="text-5xl font-black text-red-700 leading-none">{results.wrong}</p>
              </div>
              <div className="bg-indigo-50 p-8 rounded-[2rem] text-center border border-indigo-100">
                <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-2">Skipped</p>
                <p className="text-5xl font-black text-indigo-700 leading-none">{results.unattempted}</p>
              </div>
            </div>

            <div className="space-y-6">
              <h3 className="text-3xl font-black text-slate-900 border-b-4 border-slate-50 pb-6">Detailed Answer Review</h3>
              {activeQuiz.subQuestions.map((sq, idx) => {
                const resp = user.responses.find(r => r.subQuestionId === sq.id);
                const isCorrect = resp?.selectedOptionIndex === sq.correctAnswerIndex;
                return (
                  <div key={sq.id} className={`p-8 rounded-[2.5rem] border-2 shadow-sm ${!resp ? 'bg-slate-50 border-slate-100' : isCorrect ? 'bg-emerald-50/40 border-emerald-100' : 'bg-red-50/40 border-red-100'}`}>
                    <div className="flex items-start gap-6 mb-6">
                      <span className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-black text-lg ${!resp ? 'bg-slate-300 text-white' : isCorrect ? 'bg-emerald-500 text-white' : 'bg-red-500 text-white'}`}>
                        {idx + 1}
                      </span>
                      <p className="font-bold text-slate-800 text-xl pt-1 leading-tight">{sq.questionText}</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 ml-0 md:ml-16">
                      <div className="p-4 rounded-2xl bg-white border border-slate-100 shadow-sm">
                        <span className="text-[9px] font-black uppercase text-slate-400 block mb-1 tracking-widest">Candidate Choice</span>
                        <span className="font-black text-slate-700">{resp ? sq.options[resp.selectedOptionIndex] : <span className="italic text-slate-300">Skipped</span>}</span>
                      </div>
                      <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-100 shadow-sm">
                        <span className="text-[9px] font-black uppercase text-emerald-600 block mb-1 tracking-widest">Correct Solution</span>
                        <span className="font-black text-emerald-700">{sq.options[sq.correctAnswerIndex]}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-20 flex justify-center">
              <Button size="lg" className="px-20 py-6 text-2xl font-black rounded-[2rem] shadow-2xl shadow-indigo-100 hover:scale-105 transition-all" onClick={() => { setView('DASHBOARD'); setResults(null); setActiveQuiz(null); }}>Return to Dashboard</Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // QUIZ VIEW
  if (view === 'QUIZ' && activeQuiz) {
    const currentSq = activeQuiz.subQuestions[currentQuestionIndex];
    const response = user.responses.find(r => r.subQuestionId === currentSq.id);

    return (
      <div className="min-h-screen bg-slate-50 p-4 md:p-8">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row gap-8">
          
          <div className="w-full lg:w-1/2 space-y-6 lg:sticky lg:top-8 max-h-[calc(100vh-4rem)] overflow-y-auto pb-10 scrollbar-hide">
            <div className="bg-white rounded-[3rem] shadow-2xl border border-slate-100 p-8">
              <div className="flex justify-between items-center mb-8">
                <h3 className="text-[10px] font-black text-indigo-900 tracking-[0.3em] uppercase">Visual Context</h3>
                <Button variant="ghost" size="sm" className="font-bold text-slate-400" onClick={() => { if(confirm('Exit current assessment? Progress will be reset.')) setView('DASHBOARD'); }}>Exit</Button>
              </div>

              {activeQuiz.mainQuestionMediaData && (
                <div className="bg-slate-900 rounded-[2rem] overflow-hidden mb-6 aspect-video relative border-4 border-slate-50 shadow-inner">
                  {activeQuiz.mainQuestionMediaType === 'image' ? (
                    <img src={activeQuiz.mainQuestionMediaData} className="w-full h-full object-contain" />
                  ) : (
                    <iframe src={activeQuiz.mainQuestionMediaData} className="w-full h-full border-none bg-white" />
                  )}
                  <button onClick={() => setIsZoomed(true)} className="absolute bottom-6 right-6 bg-white/20 backdrop-blur-md text-white text-[10px] font-black px-4 py-2 rounded-full border border-white/20">Expand</button>
                </div>
              )}

              <div className="bg-slate-50 p-8 rounded-[2rem] border border-slate-100 shadow-inner mb-8">
                <p className="text-slate-700 leading-relaxed text-lg font-medium italic">"{activeQuiz.description}"</p>
              </div>

              <div className="pt-8 border-t border-slate-100">
                <Button className="w-full py-5 rounded-2xl text-xl font-black shadow-xl shadow-emerald-50" variant="success" onClick={handleFinishAssessment}>FINISH & SEE MARKS</Button>
              </div>
            </div>
          </div>

          <div className="flex-1 space-y-6">
            <header className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 flex items-center justify-between">
              <div>
                <h2 className="font-black text-2xl text-slate-900 mb-1 leading-tight">{activeQuiz.title}</h2>
                <p className="text-slate-400 font-bold uppercase text-[10px] tracking-widest">Question {currentQuestionIndex + 1} / {activeQuiz.subQuestions.length}</p>
              </div>
            </header>

            <main className={`p-10 bg-white rounded-[3.5rem] shadow-sm border-4 transition-all duration-300 min-h-[500px] flex flex-col ${response ? 'border-emerald-50 bg-emerald-50/5' : 'border-slate-50'}`}>
              <div className="flex-1">
                <div className="flex items-start gap-6 mb-12">
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 font-black text-xl shadow-lg transition-all ${response ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-300'}`}>
                    {currentQuestionIndex + 1}
                  </div>
                  <h4 className="text-2xl font-black text-slate-800 pt-2 leading-tight">{currentSq.questionText}</h4>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {currentSq.options.map((opt, optIdx) => (
                    <button
                      key={optIdx}
                      onClick={() => handleAnswer(activeQuiz.id, currentSq.id, optIdx)}
                      className={`p-6 text-left rounded-3xl border-2 text-lg font-bold transition-all flex items-center gap-6 ${
                        response?.selectedOptionIndex === optIdx 
                          ? 'bg-indigo-600 text-white border-indigo-600 shadow-xl' 
                          : 'bg-white text-slate-700 border-slate-100 hover:border-indigo-200'
                      }`}
                    >
                      <span className={`w-10 h-10 rounded-xl flex items-center justify-center text-xs font-black transition-colors ${response?.selectedOptionIndex === optIdx ? 'bg-white/20' : 'bg-slate-100 text-slate-400'}`}>
                        {String.fromCharCode(65 + optIdx)}
                      </span>
                      {opt}
                    </button>
                  ))}
                </div>
              </div>

              <div className="mt-16 flex justify-between items-center pt-8 border-t border-slate-50">
                <Button variant="ghost" className="font-black text-slate-400 px-8 text-lg" onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))} disabled={currentQuestionIndex === 0}>BACK</Button>
                {currentQuestionIndex === activeQuiz.subQuestions.length - 1 ? (
                   <Button variant="success" className="px-16 py-5 font-black rounded-2xl shadow-xl text-xl" onClick={handleFinishAssessment}>SUBMIT</Button>
                ) : (
                   <Button className="px-16 py-5 font-black rounded-2xl shadow-xl text-xl" onClick={() => setCurrentQuestionIndex(currentQuestionIndex + 1)}>CONTINUE</Button>
                )}
              </div>
            </main>

            <div className="bg-white rounded-[2.5rem] shadow-2xl border border-slate-100 p-10">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-10 text-center">Progress (Attended = Green)</h4>
              <div className="flex flex-wrap justify-center gap-5">
                {activeQuiz.subQuestions.map((sq, idx) => {
                  const status = getSubQuestionStatus(sq.id);
                  const isActive = currentQuestionIndex === idx;
                  return (
                    <button
                      key={sq.id}
                      onClick={() => setCurrentQuestionIndex(idx)}
                      className={`w-12 h-12 rounded-xl flex items-center justify-center font-black text-lg transition-all ${
                        isActive ? 'bg-indigo-100 text-indigo-700 ring-4 ring-indigo-600 shadow-lg' : 
                        status === 'ATTENDED' ? 'bg-emerald-600 text-white shadow-md' : 'bg-white text-slate-300 border-2 border-slate-100'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {isZoomed && activeQuiz.mainQuestionMediaData && (
          <div className="fixed inset-0 z-[100] bg-slate-900/98 flex items-center justify-center p-8 backdrop-blur-xl" onClick={() => setIsZoomed(false)}>
            <div className="relative w-full h-full flex items-center justify-center">
              <button className="absolute -top-12 right-0 text-white text-7xl font-light p-4">&times;</button>
              {activeQuiz.mainQuestionMediaType === 'image' ? (
                <img src={activeQuiz.mainQuestionMediaData} className="max-w-full max-h-full object-contain shadow-2xl rounded-[3rem] border-4 border-white/10" />
              ) : (
                <iframe src={activeQuiz.mainQuestionMediaData} className="w-full h-full bg-white rounded-[4rem] shadow-2xl" />
              )}
            </div>
          </div>
        )}
      </div>
    );
  }

  // DASHBOARD
  return (
    <div className="min-h-screen bg-slate-50 p-6 md:p-12">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-12 mb-20">
          <div>
            <h1 className="text-7xl font-black text-slate-900 tracking-tighter mb-4 leading-none">My Assessments</h1>
            <p className="text-slate-500 text-3xl font-medium tracking-tight">Active Student: <span className="text-indigo-600 font-black">{user.name}</span></p>
          </div>
          <Button variant="secondary" className="px-10 py-4 rounded-2xl font-black border-2 text-lg shadow-sm" onClick={() => setUser(null)}>Log Out</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {quizzes.map(quiz => (
            <div 
              key={quiz.id} 
              className="group bg-white rounded-[4rem] shadow-sm border border-slate-100 overflow-hidden hover:shadow-4xl hover:-translate-y-4 transition-all duration-700 cursor-pointer flex flex-col h-[540px]"
              onClick={() => handleSelectQuiz(quiz)}
            >
              <div className="h-64 relative overflow-hidden bg-slate-100">
                {quiz.mainQuestionMediaData ? (
                    <img src={quiz.mainQuestionMediaData} className="w-full h-full object-cover group-hover:scale-125 transition-all duration-1000" />
                  ) : (
                    <div className="w-full h-full bg-indigo-50 flex items-center justify-center">
                      <svg className="w-20 h-20 text-indigo-100" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a6 6 0 00-6 6v3.586l-.707.707A1 1 0 004 14h12a1 1 0 00.707-1.707L16 11.586V8a6 6 0 00-6-6zM10 18a3 3 0 01-3-3h6a3 3 0 01-3 3z"></path></svg>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-indigo-900/60 opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center">
                    <span className="text-white font-black text-4xl tracking-tighter">START ASSESSMENT</span>
                  </div>
              </div>
              <div className="p-10 flex-1 flex flex-col">
                <h3 className="text-3xl font-black text-slate-900 mb-4 group-hover:text-indigo-600 transition-colors line-clamp-1 leading-tight">{quiz.title}</h3>
                <p className="text-slate-500 line-clamp-3 font-medium mb-10 text-xl leading-relaxed">{quiz.description}</p>
                <div className="mt-auto pt-8 border-t border-slate-50 flex justify-between items-center text-[10px] font-black tracking-widest text-slate-400">
                  <span>{quiz.subQuestions.length} ITEMS</span>
                  <span>{new Date(quiz.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
          {quizzes.length === 0 && (
            <div className="col-span-full py-40 text-center text-slate-200 font-black border-4 border-dashed border-slate-100 rounded-[4rem]">
              <p className="text-3xl uppercase tracking-widest opacity-30">Assessment List Empty</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
