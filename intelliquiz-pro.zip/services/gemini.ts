
import { GoogleGenAI, Type } from "@google/genai";

// Use process.env.API_KEY directly for initialization as per guidelines
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const analyzeQuizContext = async (mediaData: string, mediaType: 'image' | 'pdf') => {
  try {
    const mimeType = mediaType === 'image' ? 'image/png' : 'application/pdf';
    
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: mediaData.split(',')[1],
              mimeType: mimeType
            }
          },
          {
            text: "Based on this content, generate 3 multiple-choice questions. For each question, provide 4 options and the correct answer index (0-3)."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              questionText: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              correctAnswerIndex: { type: Type.NUMBER }
            },
            required: ["questionText", "options", "correctAnswerIndex"]
          }
        }
      }
    });

    // Access .text as a property as per guidelines
    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return [];
  }
};
